# Always Payment System

نظام دفع إلكتروني متكامل مع تكامل تلقائي مع Telegram Bot ودعم كامل لأنظمة الدفع الحكومية الخليجية.

## المميزات الرئيسية

- 🏦 **أنظمة الدفع الحكومية**: دعم كامل لأنظمة الدفع الحكومية في دول الخليج
  - 🇸🇦 السعودية - سداد (SADAD)
  - 🇦🇪 الإمارات - الدرهم الإلكتروني (eDirham)
  - 🇰🇼 الكويت - كي نت (KNET)
  - 🇶🇦 قطر - بوابة الدفع الحكومي
  - 🇴🇲 عمان - مال (Maal)
  - 🇧🇭 البحرين - بنفت (BENEFIT)

- 💳 **صفحات دفع مخصصة**: واجهات مصممة خصيصاً لكل نظام دفع حكومي
- 📱 **تصميم متجاوب**: يعمل على جميع الأجهزة (موبايل، تابلت، ديسكتوب)
- 🔐 **أمان عالي**: تشفير وحماية البيانات الحساسة
- 📬 **تكامل مع Telegram**: إشعارات فورية لجميع المعاملات
- 🌍 **دعم متعدد العملات**: دعم جميع عملات دول الخليج
- 🎨 **تصميم حكومي أصيل**: نسخ دقيقة من تصاميم أنظمة الدفع الحكومية

## المتطلبات

- Node.js 20.12.1 أو أحدث
- npm 10.5.0 أو أحدث
- حساب Supabase (للبيانات)
- Telegram Bot Token (للإشعارات)

## التثبيت

1. **استنساخ المستودع:**
```bash
git clone https://github.com/you3333ef/Youssef-Dafa.git
cd Youssef-Dafa
```

2. **تثبيت المكتبات:**
```bash
npm install
```

3. **إعداد متغيرات البيئة:**
```bash
cp .env.example .env
```

ثم قم بتعديل ملف `.env` وإضافة بيانات الاعتماد الخاصة بك:

```env
# Telegram Bot Configuration
VITE_TELEGRAM_BOT_TOKEN=your_bot_token_here
VITE_TELEGRAM_CHAT_ID=your_chat_id_here

# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_url_here
VITE_SUPABASE_PUBLISHABLE_KEY=your_supabase_anon_key_here
```

### الحصول على Telegram Bot Token

1. افتح Telegram وابحث عن `@BotFather`
2. أرسل الأمر `/newbot`
3. اتبع التعليمات لإنشاء البوت
4. احفظ الـ Token الذي سيرسله لك BotFather

### الحصول على Telegram Chat ID

1. ابدأ محادثة مع البوت الخاص بك
2. أرسل أي رسالة إلى البوت
3. افتح المتصفح وزر: `https://api.telegram.org/bot<BOT_TOKEN>/getUpdates`
4. ابحث عن `"chat":{"id":` في النتيجة - هذا هو Chat ID الخاص بك
5. أو استخدم ملف `get-user-chat-id.html` الموجود في المشروع

## التطوير

### تشغيل الخادم المحلي:
```bash
npm run dev
```

سيعمل التطبيق على: `http://localhost:8080`

### البناء للإنتاج:
```bash
npm run build
```

### معاينة البناء:
```bash
npm run preview
```

## البنية الرئيسية

```
├── src/
│   ├── components/          # المكونات القابلة لإعادة الاستخدام
│   │   └── ui/             # مكونات الواجهة (shadcn/ui)
│   ├── pages/              # صفحات التطبيق
│   │   ├── Index.tsx       # الصفحة الرئيسية
│   │   ├── PaymentRecipient.tsx    # بيانات المستلم
│   │   ├── PaymentDetails.tsx      # تفاصيل الدفع
│   │   ├── PaymentBankSelector.tsx # اختيار البنك
│   │   ├── PaymentCardInput.tsx    # إدخال بيانات البطاقة
│   │   ├── PaymentBankLogin.tsx    # تسجيل الدخول البنكي
│   │   ├── PaymentOTP.tsx          # إدخال رمز التحقق
│   │   └── PaymentReceipt.tsx      # إيصال الدفع
│   ├── lib/                # المكتبات والوظائف المساعدة
│   │   ├── governmentPaymentSystems.ts  # أنظمة الدفع الحكومية
│   │   ├── banks.ts                     # بيانات البنوك
│   │   ├── countries.ts                 # بيانات الدول
│   │   ├── countryCurrencies.ts         # العملات
│   │   ├── telegram.ts                  # تكامل Telegram
│   │   └── serviceLogos.ts              # شعارات الخدمات
│   ├── integrations/       # التكاملات الخارجية
│   │   └── supabase/       # تكامل Supabase
│   └── assets/             # الصور والملفات الثابتة
├── public/                 # الملفات العامة
├── netlify/                # Netlify Functions & Edge Functions
└── dist/                   # مجلد البناء (يتم إنشاؤه)
```

## تدفق الدفع

1. **اختيار الخدمة** → المستخدم يختار الخدمة المطلوبة
2. **بيانات المستلم** → إدخال بيانات المستلم والمبلغ والخدمة الحكومية
3. **تفاصيل الدفع** → مراجعة التفاصيل
4. **اختيار البنك** → اختيار البنك المصدر للبطاقة (اختياري)
5. **إدخال البطاقة** → إدخال بيانات البطاقة
6. **تسجيل الدخول البنكي** → التحقق من الهوية عبر البنك
7. **OTP** → إدخال رمز التحقق
8. **الإيصال** → عرض إيصال الدفع

## النشر على Netlify

1. **إنشاء حساب Netlify** على [netlify.com](https://netlify.com)

2. **ربط المستودع:**
   - اختر "New site from Git"
   - اختر GitHub واختر المستودع

3. **إعدادات البناء:**
   - Build command: `npm run build`
   - Publish directory: `dist`

4. **متغيرات البيئة:**
   - اذهب إلى Site settings → Environment variables
   - أضف جميع المتغيرات من ملف `.env`

5. **Deploy!**

## الأمان

⚠️ **مهم جداً - ممارسات الأمان:**

1. **لا تشارك ملف `.env`** - هذا الملف يحتوي على بيانات حساسة
2. **لا ترفع `.env` إلى Git** - الملف مستثنى في `.gitignore`
3. **استخدم HTTPS دائماً** في الإنتاج
4. **قم بتدوير الـ Tokens** بشكل دوري
5. **لا تخزن بيانات البطاقة** - استخدم معالجات دفع آمنة فقط

## التقنيات المستخدمة

- ⚛️ **React 18** - مكتبة واجهة المستخدم
- 📘 **TypeScript** - لغة البرمجة
- 🎨 **Tailwind CSS** - إطار عمل التصميم
- 🧩 **shadcn/ui** - مكونات الواجهة
- 🔥 **Vite** - أداة البناء
- 🗄️ **Supabase** - قاعدة البيانات
- 📡 **React Query** - إدارة الحالة والبيانات
- 🚀 **Netlify** - الاستضافة والـ Serverless Functions

## المساهمة

المساهمات مرحب بها! يرجى:

1. Fork المستودع
2. إنشاء فرع للميزة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push إلى الفرع (`git push origin feature/amazing-feature`)
5. فتح Pull Request

## الترخيص

هذا المشروع مفتوح المصدر ومتاح للاستخدام الشخصي والتجاري.

## الدعم

للمساعدة والدعم:
- افتح Issue على GitHub
- راسلنا على Telegram

---

صنع بـ ❤️ في المملكة العربية السعودية 🇸🇦
